package main.java.client;

public interface IChat {
	public void append(String s);
}
