package main.java.client;

public interface IEncrypter {
	
	String encrypt(String text);

}
