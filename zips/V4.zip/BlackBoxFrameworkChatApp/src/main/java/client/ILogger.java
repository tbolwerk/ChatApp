package main.java.client;

public interface ILogger {
	
	void log(String filename, String text);

}
