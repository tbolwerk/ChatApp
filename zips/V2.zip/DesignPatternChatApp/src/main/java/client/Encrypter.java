package client;

public class Encrypter implements IEncrypter {
	
	@Override
	public String encrypt(String message) {
		return message;
	}
	
}
