package client;

public interface IEncrypter {
	public String encrypt(String message);
}
