public  interface  IGUIStateComponent {
	
	public void onDisconnected();

	
	public void onDisconnecting();

	
	public void onConnected();

	
	public void onConnecting();


}
