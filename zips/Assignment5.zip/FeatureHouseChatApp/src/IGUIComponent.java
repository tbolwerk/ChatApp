import javax.swing.JPanel; 

public  interface  IGUIComponent {
	
	public JPanel createGuiComponent(Client client);


}
