public  class  LoggerStub  implements ILogger {
	
	@Override
	public void log(String filename, String text) {
		
	}


}
