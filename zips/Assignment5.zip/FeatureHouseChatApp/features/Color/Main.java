/**
 * TODO description
 */
public class Main {
	protected static IColor initColor() {
		IColor c = new ColorSelection();
		
		return c;
	}
	
}