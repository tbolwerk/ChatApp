/**
 * TODO description
 */
public class Main {
	protected static INotifier initNotifier() {
		INotifier n = new Notifier();
	
		return n;
	}
}