/**
 * TODO description
 */
public class Main {
	protected static IEncrypter initEncrypter() {
		IEncrypter e = new Encrypter();
		
		return e;
	}
}