public class NotifierStub implements INotifier {
	@Override
	public void doNotify() {

	}
}