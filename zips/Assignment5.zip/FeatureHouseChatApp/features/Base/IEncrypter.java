public interface IEncrypter {
	
	String encrypt(String text);

}
