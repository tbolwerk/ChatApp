import javax.swing.JPanel;
import javax.swing.JTextArea;

public interface IColor extends IGUIComponent {
	public void setChatText(JTextArea text);
}
