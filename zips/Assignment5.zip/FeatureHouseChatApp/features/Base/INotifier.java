/**
 * TODO description
 */
public interface INotifier {
	
	void doNotify();

}