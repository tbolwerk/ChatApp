# Test report
This report will go over three variants which were manually tested for the Feature house implementation of the ChatApp.

## Variant a
### Feature set
![Variant-A feature set](source/FeatureSetA.png)

### Image
![Variant-A image](source/VariantA.png)


### Result
Variant a works as intended.

## Variant b
### Feature set
![Variant-B feature set](source/FeatureSetB.png)

### Image
![Variant-B image](source/VariantB.png)


### Result
Variant b works as intended.

## Variant c
### Feature set
![Variant-C feature set](source/FeatureSetC.png)

### Image
![Variant-C image](source/VariantC.png)

### Result
Variant c works as intended.