# Assignment 7 report
## Task 4.a
### Static
The color feature is not used to color text when the CLI is used.

### Dynamic
We don't have dynamic feature interactions in our solutions.

### Domain
We don't have any domain dependant feature interactions.

### Implementation
The color feature is not used to color text when the CLI is used.

### Optional feature
We don't have an optional feature problem.

## Task 4.b
We prefer FOP, because:
* We think it's more explicit in defining what changes
* Doesn't require a programmer to learn an additional language
* AOP is more finegrained which makes it harder to reason about the code, which means more errors will be made.

In the future we would implement the solutions based of the base ChatApp that we made in the beginning instead of working from our other solutions to better seperate the different methods.